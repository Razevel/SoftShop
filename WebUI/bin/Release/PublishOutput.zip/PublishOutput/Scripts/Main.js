﻿
function MarkCurrentLiItem($LiId) {
    document.getElementById($LiId).className += " active";
}